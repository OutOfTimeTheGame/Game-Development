﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Level1Controller : MonoBehaviour {

    public int score;


    //The Player's Score text which will be displayed on the screen
    public int health;
    
	// Use this for initialization
	void Start ()
    {
        health = 10;        
	}

   

    // Update is called once per frame
    void Update ()
    {
		
	}
}
