﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PistolPlasmaRight : MonoBehaviour
{
    public float plasmaSpeed = 8.0f;
    public Rigidbody2D rb2;
	// Use this for initialization
	void Start ()
    {
        rb2 = GetComponent<Rigidbody2D>();

        rb2.velocity = transform.right * plasmaSpeed;
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
